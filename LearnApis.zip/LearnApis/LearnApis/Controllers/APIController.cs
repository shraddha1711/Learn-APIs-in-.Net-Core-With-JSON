﻿using LearnApis.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LearnApis.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class APIController : ControllerBase
    {
        private readonly ProductService _productService;

        public APIController(ProductService productService)
        {
            _productService = productService;
        }

        // GET: api/ProductApi
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            var products = await _productService.GetProductsAsync();

            if (products == null || !products.Any())
            {
                return NotFound("No products found.");
            }

            return Ok(products); // Return 200 OK with the products data
        }

        // GET: api/ProductApi/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            var products = await _productService.GetProductsAsync();
            var product = products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        // POST: api/ProductApi
        [HttpPost]
        public async Task<ActionResult> CreateProduct([FromBody] Product newProduct)
        {
            var products = await _productService.GetProductsAsync();
            newProduct.Id = products.Max(p => p.Id) + 1; // Assign a new ID
            products.Add(newProduct);

            // Save the updated list back to products.json (you'll need a save method)
            await _productService.SaveProductsAsync(products);

            return CreatedAtAction(nameof(GetProduct), new { id = newProduct.Id }, newProduct);
        }

        // PUT: api/ProductApi/5
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateProduct(int id, [FromBody] Product updatedProduct)
        {
            var products = await _productService.GetProductsAsync();
            var product = products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            product.Name = updatedProduct.Name;
            product.Price = updatedProduct.Price;

            await _productService.SaveProductsAsync(products);

            return NoContent();
        }

        // DELETE: api/ProductApi/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteProduct(int id)
        {
            var products = await _productService.GetProductsAsync();
            var product = products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            products.Remove(product);

            // Save the updated list back to products.json
            await _productService.SaveProductsAsync(products);

            return NoContent();
        }

        #region New Task Add To Do List

        [HttpGet("all-products")]
        public async Task<ActionResult<IEnumerable<ProductTask>>> GetProductsTask()
        {
            var products = await _productService.GetToDoList();

            if (products == null || !products.Any())
            {
                return Ok(new List<ProductTask>());
            }

            return Ok(products);
        }

        [HttpGet("product/{id}")]
        public async Task<ActionResult<ProductTask>> GetProducttask(int id)
        {
            var products = await _productService.GetToDoList();
            var product = products.FirstOrDefault(s => s.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        [HttpPost("product")]
        public async Task<ActionResult> AddNewTask(ProductTask pt)
        {
            var GetProduct = await _productService.GetToDoList();
            pt.Id = GetProduct.Max(s => s.Id) + 1;
            GetProduct.Add(pt);
            await _productService.SaveToDoList(GetProduct);
            return CreatedAtAction(nameof(GetProducttask), new { id = pt.Id }, pt);
        }

        [HttpPut("product/{id}")]
        public async Task<ActionResult> UpdateNewTask(int id, [FromBody] ProductTask up)
        {
            var products = await _productService.GetToDoList();
            var product = products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            product.TaskName = up.TaskName;
            product.Status = up.Status;

            await _productService.SaveToDoList(products);
            return NoContent();
        }

        [HttpDelete("product/{id}")]
        public async Task<ActionResult> DeleteProducttask(int id)
        {
            var productss = await _productService.GetToDoList();
            var product = productss.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            productss.Remove(product);

            // Save the updated list back to products.json
            await _productService.SaveToDoList(productss);

            return NoContent();
        }

        #endregion

    }
}
