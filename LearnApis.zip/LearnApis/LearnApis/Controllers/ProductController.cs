﻿using LearnApis.Models;
using Microsoft.AspNetCore.Mvc;

namespace LearnApis.Controllers
{

    //#region This is Through c#
    //public class ProductController : Controller
    //{

    //    // In-memory list to store products
    //    private static List<Product> _products = new List<Product>
    //    {
    //        new Product { Id = 1, Name = "Laptop", Price = 999.99M },
    //        new Product { Id = 2, Name = "Smartphone", Price = 499.99M }
    //    };

    //    // GET: /Products/
    //    public IActionResult Index()
    //    {
    //        return View(_products);
    //    }
    //    // GET: /Products/Details/1
    //    public IActionResult Details(int id)
    //    {
    //        var product = _products.FirstOrDefault(p => p.Id == id);
    //        if (product == null)
    //        {
    //            return NotFound();
    //        }
    //        return View(product);
    //    }

    //}
    //#endregion


    #region This is Through JSON
    public class ProductController : Controller
    {
        private readonly ProductService _productService;

        // Constructor with dependency injection for ProductService
        public ProductController(ProductService productService)
        {
            _productService = productService;
        }

        // GET: /Product/
        public async Task<IActionResult> Index()
        {
            var products = await _productService.GetProductsAsync();
            return View(products);
        }

        // POST: /Product/AddProduct
        [HttpPost]
        public async Task<IActionResult> AddProduct(Product product)
        {
            if (ModelState.IsValid)
            {
                // Assuming _productService has a method to add the product to the source
                await _productService.AddProductAsync(product);
                return RedirectToAction("Index");
            }
            var products = await _productService.GetProductsAsync();
            return View("Index", products);
        }

        // GET: /Product/Details/1
        public async Task<IActionResult> Details(int id)
        {
            var products = await _productService.GetProductsAsync();
            var product = products.FirstOrDefault(p => p.Id == id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }
    }

    #endregion
}
