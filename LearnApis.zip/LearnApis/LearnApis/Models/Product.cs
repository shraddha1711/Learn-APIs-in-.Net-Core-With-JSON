﻿namespace LearnApis.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
    public class ProductTask
    {
        public int Id { get; set; }
        public string TaskName { get; set; }
        public string Status { get; set; }
    }
}
