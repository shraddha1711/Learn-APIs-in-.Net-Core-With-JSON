﻿using System.Text.Json;

namespace LearnApis.Models
{
    public class ProductService
    {
        private readonly string _filePath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "products.json");
        private readonly string _path = Path.Combine(Directory.GetCurrentDirectory(), "Data", "ToDoTask.JSON");

        // Get all products
        public async Task<List<Product>> GetProductsAsync()
        {
            if (!File.Exists(_filePath))
            {
                return new List<Product>();
            }

            var json = await File.ReadAllTextAsync(_filePath);
            return JsonSerializer.Deserialize<List<Product>>(json) ?? new List<Product>();
        }

        // Save all products to the JSON file
        public async Task SaveProductsAsync(List<Product> products)
        {
            var json = JsonSerializer.Serialize(products, new JsonSerializerOptions { WriteIndented = true });
            await File.WriteAllTextAsync(_filePath, json);
        }

        // Add a product to the list and save it
        public async Task AddProductAsync(Product product)
        {
            // Get existing products
            var products = await GetProductsAsync();

            // Add the new product
            products.Add(product);

            // Save the updated list of products
            await SaveProductsAsync(products);
        }

        // Save ToDo list (for ProductTask objects)
        public async Task SaveToDoList(List<ProductTask> pt)
        {
            var json = JsonSerializer.Serialize(pt, new JsonSerializerOptions { WriteIndented = true });
            await File.WriteAllTextAsync(_path, json);
        }

        // Get ToDo list (for ProductTask objects)
        public async Task<List<ProductTask>> GetToDoList()
        {
            if (!File.Exists(_path))
            {
                return new List<ProductTask>();
            }

            try
            {
                var json = await File.ReadAllTextAsync(_path);
                return JsonSerializer.Deserialize<List<ProductTask>>(json) ?? new List<ProductTask>();
            }
            catch (Exception ex)
            {
                // Handle any errors like JSON deserialization errors
                Console.WriteLine($"Error reading or deserializing file: {ex.Message}");
                return new List<ProductTask>();
            }
        }
    }

}
